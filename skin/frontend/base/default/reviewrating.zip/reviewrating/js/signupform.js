// Validating Empty Field

  (function($, window, document, undefined) {
function showPopup(sUrl) {
    oPopup = new Window({
    id:'popup_window',
    className: 'magento',
    url: sUrl,
    width: 820,
    height: 600,
    minimizable: false,
    maximizable: false,
    showEffectOptions: {
        duration: 0.4
    },
    hideEffectOptions:{
        duration: 0.4
    },
    destroyOnClose: true
    });
    oPopup.setZIndex(100);
    oPopup.showCenter(true);
}

function closePopup() {
    Windows.close('popup_window');
}

      
//       $(".reviewBtn").on("click", function(){
//       // alert('I am form');
//       // document.getElementById('popup').style.display = "block";
//       win = new Window({className: "magento", title: "Sample", width:200, height:150, destroyOnClose: true, recenterAuto:false});

// win.getContent().update("<h1>Hello world !!</h1>");
// win.showCenter();

//       });
    })(jQuery, window, document);

function check_empty() {
if (document.getElementById('name').value == "" || document.getElementById('email').value == "" || document.getElementById('msg').value == "") {
alert("Fill All Fields !");
} else {
document.getElementById('form').submit();
alert("Form Submitted Successfully...");
}
}

//Function to Hide Popup
function div_hide(){
document.getElementById('popup').style.display = "none";
}