(function($, window, document, undefined) {
	jQuery('.owl-carousel-vertical').owlCarousel({
    loop:true,
    margin:20,
    nav:true,
    // autoplay: true,
    // autoplayTimeout: 5000,
    navText : ['<i class="fa fa-angle-left" aria-hidden="true"></i>','<i class="fa fa-angle-right" aria-hidden="true"></i>'],
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:2
        }
    }
});

     $('.owl-carousel-horizontal').owlCarousel({
        loop:true,
        margin:10,
        nav:true,
        responsive:{
            0:{
                items:1
            },
            600:{
                items:2
            },
            1000:{
                items:3
            }
        }
    });

})(jQuery, window, document);