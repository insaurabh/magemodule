
// Polyfill for Old Browser
if (typeof Object.create !== "function") {
    Object.create = function(obj) {
        function F() {};
        F.prototype = obj;
        return new F();
    }
}

(function($, window, document, undefined) {
        var obj = '';
      
            // $(document).on('click',function() {
            //   $(".hb-rating-wrapper").css("background-color", "red");
            // });
       function changeBgColor(){
       	return "I am from js";
       }     
   


})(jQuery, window, document);
 